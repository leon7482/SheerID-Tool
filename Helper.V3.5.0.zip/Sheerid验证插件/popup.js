// popup.js
let turnstileToken = null;

// 当前扩展版本（来自 manifest.json）
const CURRENT_VERSION = chrome.runtime.getManifest().version;
// 版本元信息接口（需要你在后端提供）
const META_URL = "https://my-sheerid-bot.vercel.app/api/ext-meta";

// 是否因为版本过旧而强制禁用启动按钮
let versionBlocked = false;

const ui = {
  btn: document.getElementById("startBtn"),
  payBtn: document.getElementById("payBtn"),
  urlInput: document.getElementById("urlInput"),
  logBox: document.getElementById("logArea"),

  // 日志输出到 popup 的日志区域（字体纯黑，样式由 CSS 控制）
  log(msg, color = "#000") {
    console.log(`[PopupLog] ${msg}`);
    if (!this.logBox) return;

    // 第一次写日志时，移除“暂无日志”占位
    const empty = this.logBox.querySelector(".log-empty");
    if (empty) {
      empty.remove();
    }

    const line = document.createElement("div");
    line.className = "log-line";

    const timeSpan = document.createElement("span");
    timeSpan.className = "log-time";
    timeSpan.textContent = new Date().toLocaleTimeString();

    const textSpan = document.createElement("span");
    textSpan.className = "log-text";
    textSpan.textContent = " " + msg;

    line.appendChild(timeSpan);
    line.appendChild(textSpan);
    this.logBox.appendChild(line);

    this.logBox.scrollTop = this.logBox.scrollHeight;
  },

  // 根据验证 / 版本状态更新启动按钮
  updateButtonState(active) {
    // 如果版本被判定为过旧，则始终保持禁用状态
    if (versionBlocked) {
      this.btn.disabled = true;
      this.btn.textContent = "版本已过期，请更新";
      this.btn.style.background = "#9ca3af";
      return;
    }

    if (active) {
      this.btn.disabled = false;
      this.btn.textContent = "启动自动化验证";
      this.btn.style.background = "#2563eb";
    } else {
      this.btn.disabled = true;
      this.btn.textContent = "请先完成上方验证";
      this.btn.style.background = "#d1d5db";
    }
  }
};

// 简单版本号比较函数，如 "3.5.0" vs "3.6.1"
function compareVersion(a, b) {
  const pa = (a || "").split(".").map(Number);
  const pb = (b || "").split(".").map(Number);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const x = pa[i] || 0;
    const y = pb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

// 打开 popup 时检查后端的最新版本信息
function checkVersionMeta() {
  fetch(META_URL, { cache: "no-store" })
    .then((res) => res.json())
    .then((meta) => {
      if (!meta) return;

      const latest = meta.latestVersion || "";
      const minSupported = meta.minSupportedVersion || "";
      const downloadUrl = meta.downloadUrl || "";
      const notice = meta.notice || "";

      // 当前版本太旧：写明显提示 & 永久禁用“启动自动化验证”按钮
      if (minSupported && compareVersion(CURRENT_VERSION, minSupported) < 0) {
        versionBlocked = true;
        ui.log(
          `⚠️ 当前版本 v${CURRENT_VERSION} 已过期，请下载 v${latest || minSupported} 并重新安装扩展。`
        );
        if (downloadUrl) {
          ui.log(`👉 更新包下载地址：${downloadUrl}`);
        }
        if (notice) {
          ui.log(notice);
        }
        ui.updateButtonState(false);
        return;
      }

      // 有新版本，但当前仍在支持范围内：在日志顶部提示“有更新”
      if (latest && compareVersion(CURRENT_VERSION, latest) < 0) {
        ui.log(`⬆️ 检测到新版本 v${latest}，建议下载最新插件版本。`);
        if (downloadUrl) {
          ui.log(`👉 更新包下载地址：${downloadUrl}`);
        }
        if (notice) {
          ui.log(notice);
        }
      }
    })
    .catch(() => {
      // 静默失败，不影响正常使用
    });
}

// 载入已有的任务日志（来自 background.js 写入的 taskLogs）
chrome.storage.local.get(["taskLogs"], (data) => {
  const logs = data.taskLogs || [];
  logs.forEach((entry) => {
    const text = entry && entry.text ? entry.text : String(entry);
    ui.log(text);
  });
});

// 监听日志变化，实时追加到 popup
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local" || !changes.taskLogs) return;
  const oldLogs = changes.taskLogs.oldValue || [];
  const newLogs = changes.taskLogs.newValue || [];
  if (newLogs.length <= oldLogs.length) return;
  const appended = newLogs.slice(oldLogs.length);
  appended.forEach((entry) => {
    const text = entry && entry.text ? entry.text : String(entry);
    ui.log(text);
  });
});

// 接收 Turnstile 验证结果
window.addEventListener("message", (event) => {
  if (event.origin !== "https://my-sheerid-bot.vercel.app") return;
  if (event.data?.type === "TURNSTILE_TOKEN" && event.data.token) {
    turnstileToken = event.data.token;
    ui.updateButtonState(true);
    ui.log("验证已通过，可以启动任务。");
  }
});

// --- 启动按钮逻辑 ---
ui.btn.onclick = async () => {
  // 如果版本被标记为过旧，直接拦截
  if (versionBlocked) {
    ui.log("当前插件版本已过期，无法启动任务，请先更新插件版本。");
    return;
  }

  const url = ui.urlInput.value.trim();
  if (!url) {
    ui.log("请输入验证页面链接。");
    ui.urlInput.style.borderColor = "red";
    setTimeout(() => (ui.urlInput.style.borderColor = "#e5e7eb"), 1000);
    return;
  }
  if (!turnstileToken) {
    ui.log("尚未通过上方验证。");
    return;
  }

  await chrome.storage.local.set({
    autoTask: {
      running: true,
      token: turnstileToken,
      startTime: Date.now()
    },
    taskLogs: [] // 重置日志
  });

  ui.log("任务已启动，正在打开目标页面…");

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    chrome.tabs.update(tab.id, { url: url });
  }
};

ui.payBtn.onclick = () => {
  const rechargeUrl = "https://work.weixin.qq.com/kfid/kfc008f8b07ca835d99";
  window.open(rechargeUrl, "_blank");
};

checkVersionMeta();
