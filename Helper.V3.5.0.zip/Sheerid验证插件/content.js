;(async function () {
  if (!location.hostname.includes('sheerid')) return;

  if (document.readyState === 'loading') {
    await new Promise((resolve) =>
      document.addEventListener('DOMContentLoaded', resolve, { once: true }),
    );
  }

  const log = (...args) => console.log('[AutoTask]', ...args);

  // ===== 顶部状态条（保持原来样式：文字居中 + 阴影） =====
  function showStatus(msg, color = 'blue') {
    let el = document.getElementById('bot-status-bar');
    if (!el) {
      el = document.createElement('div');
      el.id = 'bot-status-bar';
      el.style.cssText = [
        'position:fixed',
        'top:0',
        'left:0',
        'width:100%',
        'padding:12px 16px',
        'z-index:999999',
        'color:#fff',
        'text-align:center',
        'font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif',
        'font-size:14px',
        'box-shadow:0 2px 8px rgba(0,0,0,0.4)',
        'transition:background-color .3s',
      ].join(';');
      document.body.appendChild(el);
    }

    const colors = {
      blue: '#2563EB',
      green: '#16A34A',
      red: '#DC2626',
      orange: '#EA580C',
      gray: '#4B5563',
    };

    el.style.backgroundColor = colors[color] || colors.blue;
    el.textContent = msg;
  }

  // ===== 提取 verificationId，用于“只跑一次 Step1” =====
  function getVerificationId() {
    const params = new URLSearchParams(location.search);
    let vid = params.get('verificationId');
    if (!vid) {
      const parts = location.pathname.split('/');
      const last = parts[parts.length - 1] || '';
      if (/^[0-9a-fA-F]{24}$/.test(last)) vid = last;
    }
    return vid || null;
  }

  const verificationId = getVerificationId();
  const apiFlagKey = verificationId ? `sheerid_api_submitted_${verificationId}` : null;
  const apiAlreadySubmitted =
    apiFlagKey && window.sessionStorage.getItem(apiFlagKey) === '1';

  // ===== 结果轮询（Step2/上传之后用） =====
  function startPollingResult() {
    log('start polling');
    let timeLeft = 60;

    const timer = setInterval(() => {
      timeLeft--;
      const txt = (document.body.innerText || '').toLowerCase();

      // 成功
      if (
        txt.includes("you've been verified") ||
        txt.includes('you have been verified') ||
        txt.includes('successfully verified') ||
        txt.includes('verification complete')
      ) {
        clearInterval(timer);
        showStatus('✅验证成功(successfully verified)。', 'green');
        chrome.storage.local.remove('autoTask');
        return;
      }

      // 人工审核
      if (txt.includes('under review') || txt.includes('pending review')) {
        clearInterval(timer);
        showStatus('⏳资料已提交，等待审核结果。', 'orange');
        chrome.storage.local.remove('autoTask');
        return;
      }

            // 失败 / 上限 / 风控拒绝
      if (
        txt.includes('unable to confirm your eligibility') ||
        txt.includes('verification failed') ||
        txt.includes('not approved') ||
        txt.includes('document review limit exceeded') ||
        txt.includes('limit exceeded') ||
        txt.includes('we are unable to verify you at this time') ||
        txt.includes('unable to verify you') ||
        txt.includes('fraud prevention rules')
      ) {
        clearInterval(timer);

        if (
          txt.includes('we are unable to verify you at this time') ||
          txt.includes('fraud prevention rules')
        ) {
          showStatus('⚠️ 请更换干净的节点IP重新获取Sheerid验证链接。', 'red');
        } else {
          // 其他失败情况沿用原来的提示
          showStatus('❌ 当前操作未通过，请稍后再试。', 'red');
        }

        chrome.storage.local.remove('autoTask');
        return;
      }

      if (timeLeft <= 0) {
        clearInterval(timer);
        showStatus('⌛ 等待时间较长，请手动确认结果。', 'gray');
        chrome.storage.local.remove('autoTask');
      }
    }, 1000);
  }

  // ===== 注入 page-bridge.js（页面上下文调用 SheerID API） =====
  function injectPageBridge() {
    return new Promise((resolve) => {
      if (document.querySelector('script[data-sheerid-bridge="true"]')) {
        resolve(true);
        return;
      }
      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.async = false;
      script.setAttribute('data-sheerid-bridge', 'true');
      script.src = chrome.runtime.getURL('page-bridge.js');
      script.onload = () => {
        script.remove();
        resolve(true);
      };
      script.onerror = () => resolve(false);
      (document.head || document.documentElement).appendChild(script);
    });
  }

  // ===== 调用页面 API 提交身份（Step1） =====
  function submitIdentityViaApi(identity) {
    return new Promise((resolve) => {
      const handler = (event) => {
        if (!event || !event.data) return;

        const data = event.data || {};
        if (data.type !== 'API_SUBMISSION_RESULT') return;

        // 收到结果后立刻解除监听
        window.removeEventListener('message', handler);

        // 兼容三种情况：
        if (data.payload !== undefined) {
          resolve(data.payload);
        } else if (data.result !== undefined) {
          resolve(data.result);
        } else {
          resolve(data);
        }
      };

      window.addEventListener('message', handler);

      window.postMessage(
        {
          type: 'EXECUTE_API_SUBMISSION',
          identity,
        },
        '*',
      );

      // 保护：15 秒没返回就当超时
      setTimeout(() => {
        window.removeEventListener('message', handler);
        resolve({ success: false, error: 'timeout' });
      }, 15000);
    });
  }

  // ===== Step1：只执行一次 API 提交 =====
  async function attemptStep1Once(store) {
    if (apiAlreadySubmitted) {
      log('step already completed for this id, skip.');
      return { finished: false };
    }

    showStatus('🚀 正在准备自动操作（步骤 1）…', 'blue');

    let identity = store.currentIdentity;
    try {
      if (typeof window.generateLocalIdentity === 'function') {
        identity = await window.generateLocalIdentity(store);
        if (identity) {
          await new Promise((resolve) =>
            chrome.storage.local.set({ currentIdentity: identity }, resolve),
          );
        }
      }
    } catch (e) {
      log('data preparation error', e);
    }

    if (!identity) {
      showStatus('❌ 当前配置不完整，请在扩展中补全信息。', 'red');
      chrome.storage.local.remove('autoTask');
      return { finished: true };
    }

    showStatus('🚀 正在提交学生数据…', 'blue');

    try {
      const res = await submitIdentityViaApi(identity);
      log('request result =', res);

      if (res && res.success) {
        showStatus('✅ 提交成功！正在跳转中', 'green');
        if (apiFlagKey) window.sessionStorage.setItem(apiFlagKey, '1');

        setTimeout(() => location.reload(), 1000); // 只在 Step1 中刷新
        return { finished: true };
      }

      if (res && res.error) {
        const errMsg = String(res.error || '').toLowerCase();

        if (errMsg.includes('invalidstep')) {
          log('remote service indicates previous step completed, continue.');
          if (apiFlagKey) window.sessionStorage.setItem(apiFlagKey, '1');
          return { finished: false };
        }

        if (
          errMsg.includes('maximum number of verifications') ||
          errMsg.includes('limit')
        ) {
          showStatus('❌ 操作次数已达到限制，请稍后重试。', 'red');
          chrome.storage.local.remove('autoTask');
          return { finished: true };
        }

        showStatus(`❌ 操作失败：${res.error}`, 'red');
        chrome.storage.local.remove('autoTask');
        return { finished: true };
      }

      showStatus('❌ 操作失败：未知错误。', 'red');
      chrome.storage.local.remove('autoTask');
      return { finished: true };
    } catch (e) {
      log('request error in step 1', e);
      showStatus('❌ 操作异常，请查看控制台日志。', 'red');
      chrome.storage.local.remove('autoTask');
      return { finished: true };
    }
  }

  // ===== 主流程入口 =====
  chrome.storage.local.get(['autoTask', 'currentIdentity'], async (store) => {
    log('state =', store);

    if (!store.autoTask || !store.autoTask.running) {
      log('autoTask not active, skip.');
      return;
    }

    showStatus('🤖 正在初始化自动流程…', 'blue');

    await injectPageBridge();

    // Step1：在每个 verificationId 上只执行一次
    const step1Result = await attemptStep1Once(store);
    if (step1Result && step1Result.finished) {
      log('early finish, stop further steps.');
      return;
    }

    // ===== Step2 部分开始 =====

    // 规范化页面文本：全部小写 + 合并空白
    function getBodyText() {
      const raw =
        document.body.innerText ||
        document.body.textContent ||
        '';
      return raw.toLowerCase().replace(/\s+/g, ' ').trim();
    }
    log('page text sample =', getBodyText().slice(0, 200), '...');

    function getButtons() {
      return Array.from(
        document.querySelectorAll('button, a, div[role="button"]'),
      );
    }

    function findButtonByText(substrings) {
      const subs = substrings.map((s) => s.toLowerCase());
      return getButtons().find((el) => {
        const txt = (el.innerText || el.textContent || '').toLowerCase();
        return subs.some((s) => txt.includes(s));
      });
    }

    // 中间 CTA 页：SSO 回退页 “Unable to sign in? / Upload Proof of Enrollment”
    function isPreUploadCTA() {
      const bodyText = getBodyText();

      const hasTitle = bodyText.includes('verify using your school credentials');
      const hasUnable = bodyText.includes('unable to sign in?');

      const uploadProofBtn = findButtonByText([
        'upload proof of enrollment',
      ]);

      const addDocsBtn = findButtonByText([
        'add documents',
      ]);

      const result =
        !!uploadProofBtn && hasTitle && hasUnable && !addDocsBtn;

      log('intermediate page detected =', result, {
        hasUploadProofBtn: !!uploadProofBtn,
        hasAddDocsBtn: !!addDocsBtn,
        hasTitle,
        hasUnable,
      });

      return result;
    }

    // 最终上传页：标题 “Upload proof of enrollment” + 按钮 “Add documents”
    function isFinalUploadPage() {
      const bodyText = getBodyText();

      const hasTitle = bodyText.includes('upload proof of enrollment');
      const addDocsBtn = findButtonByText([
        'add documents',
      ]);

      const result = hasTitle && !!addDocsBtn;

      log('final page detected =', result, {
        hasTitle,
        hasAddDocsBtn: !!addDocsBtn,
      });

      return result;
    }

    // SSO 页面识别：标题 + “Sign in to your school” 按钮，排除 CTA / 最终上传页
    function isSignInFallbackPage() {
      const bodyText = getBodyText();

      const hasTitle = bodyText.includes('verify using your school credentials');

      const signInBtn =
        document.getElementById('sid-submit-btn-sso') ||
        findButtonByText(['sign in to your school']) ||
        findButtonByText(['sign in']);

      const result = hasTitle && !!signInBtn && !isPreUploadCTA() && !isFinalUploadPage();

      log('alternate page detected =', result, {
        hasTitle,
        hasSignInBtn: !!signInBtn,
      });

      return result;
    }

    // ===== Step2：等待 / 处理最终上传页 =====

    let finalUploadHandled = false;

function handleFinalUploadPage(reason = 'direct') {
  if (finalUploadHandled) {
    log('handleFinalPage called but already handled, reason =', reason);
    return; // 防止重复触发
  }
  if (!isFinalUploadPage()) {
    log(
      'handleFinalPage called but page not matched, reason =',
      reason,
    );
    return;
  }
  finalUploadHandled = true;

  showStatus('🚀 正在执行后端任务…', 'green');
  log('On final page (' + reason + '), sending background request.');

  chrome.storage.local.get(['autoTask'], (latestStore) => {
    const latestToken =
      latestStore &&
      latestStore.autoTask &&
      latestStore.autoTask.token
        ? latestStore.autoTask.token
        : null; // 只信最新的 Turnstile token

    if (!latestToken) {
      showStatus(
        '❌ 当前环境未准备就绪，请重新尝试。',
        'red',
      );
      chrome.storage.local.remove('autoTask');
      return;
    }

    chrome.runtime.sendMessage(
      {
        type: 'TRIGGER_CLOUD_UPLOAD',
        data: {
          token: latestToken,
          targetUrl: location.href,
          identity: store.currentIdentity,
        },
      },
      (res) => {
        log('background response =', res);
        if (res && res.success) {
          showStatus('✅ 后端任务执行完毕，等待结果…', 'green');
          startPollingResult();
        } else {
          showStatus(
            `❌ 后端任务执行失败: ${
              res && res.msg ? res.msg : '未知错误'
            }`,
            'red',
          );
          chrome.storage.local.remove('autoTask');
        }
      },
    );
  });
}

    function waitForFinalUploadPage(reason) {
      if (finalUploadHandled) return;

      if (isFinalUploadPage()) {
        log('waitForPage(): already on final page, reason =', reason);
        handleFinalUploadPage(reason + ': immediate');
        return;
      }

      showStatus('🕒 已触发页面跳转，等待加载完成…', 'orange');
      const start = Date.now();
      const maxWaitMs = 20000;

      const observer = new MutationObserver(() => {
        if (finalUploadHandled) return;
        if (isFinalUploadPage()) {
          log('final page detected by observer, reason =', reason);
          observer.disconnect();
          clearInterval(timer);
          handleFinalUploadPage(reason + ': observer');
        }
      });

      observer.observe(document.body, { childList: true, subtree: true });

      const timer = setInterval(() => {
        if (finalUploadHandled) {
          clearInterval(timer);
          observer.disconnect();
          return;
        }

        if (isFinalUploadPage()) {
          log('final page detected by polling, reason =', reason);
          clearInterval(timer);
          observer.disconnect();
          handleFinalUploadPage(reason + ': poll');
          return;
        }

        if (Date.now() - start > maxWaitMs) {
          clearInterval(timer);
          observer.disconnect();
          log(
            'waitForPage() timeout, falling back to polling. reason =',
            reason,
          );
          showStatus('⌛ 页面加载时间较长，已切换为结果轮询…', 'gray');
          startPollingResult();
        }
      }, 1000);
    }

    // 尽量模拟一次“真实点击”：pointer + mouse + click
    function simulateRealClick(el) {
      if (!el) return;
      const base = {
        bubbles: true,
        cancelable: true,
        view: window,
      };

      const eventTypes = [
        'pointerdown',
        'mousedown',
        'pointerup',
        'mouseup',
        'click',
      ];

      for (const type of eventTypes) {
        try {
          let evt;
          if (type.startsWith('pointer') && window.PointerEvent) {
            evt = new PointerEvent(type, base);
          } else {
            evt = new MouseEvent(type, base);
          }
          el.dispatchEvent(evt);
        } catch (e) {
          log('[AutoTask] simulate click dispatch error:', type, e);
        }
      }
    }

    // Step2 执行顺序：SSO → 预上传 CTA → 最终上传 → 否则轮询结果
    let ssoSignInClicked = false; // 避免重复点击 SSO 按钮

    function tryHandleStep2Page(reason) {
      log('tryHandleStep2, reason =', reason);

      // SSO fallback —— 自动点击 “Sign in to your school”，并让后台关闭新标签页
      if (isSignInFallbackPage()) {
        const signInBtn =
          document.getElementById('sid-submit-btn-sso') ||
          findButtonByText(['sign in to your school']) ||
          findButtonByText(['sign in']);

        showStatus(
          '🌀检测到SSO验证，开始验证',
          'orange',
        );

        if (signInBtn && !ssoSignInClicked) {
          ssoSignInClicked = true;
          try {
            signInBtn.click();
            log(
              '[AutoTask] auto-clicked button:',
              signInBtn.innerText,
            );
          } catch (e) {
            log('[AutoTask] failed to click button:', e);
          }
        } else if (!signInBtn) {
          log(
            '[AutoTask] target page detected but trigger button not found.',
          );
        }

        try {
          chrome.runtime.sendMessage({ type: 'CLOSE_NEW_POPUP' });
        } catch (e) {
          log('[AutoTask] send CLOSE_NEW_POPUP failed:', e);
        }

        return false;
      }

      // 预上传 CTA —— 自动点击 “Upload Proof of Enrollment”
      if (isPreUploadCTA()) {
        showStatus(
          '🌀 SSO 正在验证中...',
          'orange',
        );
        log(
          'On pre-upload CTA page, clicking "Upload Proof of Enrollment".',
        );

        const btn = findButtonByText([
          'upload proof of enrollment',
          '上传在读证明',
          '上传在校证明',
        ]);
        if (btn) {
          btn.click();
          log(
            '[AutoTask] clicked pre-upload CTA button:',
            btn.innerText,
          );
        } else {
          log(
            '[AutoTask] no "Upload Proof of Enrollment" button found on CTA page.',
          );
        }

        waitForFinalUploadPage('after-pre-upload-cta');
        return true;
      }

      // 已经在最终上传页 —— 直接触发后端上传
      if (isFinalUploadPage()) {
        handleFinalUploadPage('direct-detect');
        return true;
      }

      return false;
    }

    // 先尝试一次快速判断
    if (tryHandleStep2Page('initial')) {
      return;
    }

    // 如果首次没有识别到任何特殊页面（表单 / 上传 / SSO），再等待一会儿再检查
    let handled = false;
    const waitStart = Date.now();
    const maxWaitMs = 10000; // 最多等 10 秒

    const observer2 = new MutationObserver(() => {
      if (handled) return;
      if (tryHandleStep2Page('observer')) {
        handled = true;
        observer2.disconnect();
        clearInterval(timer2);
      }
    });

    observer2.observe(document.body, { childList: true, subtree: true });

    const timer2 = setInterval(() => {
      if (handled) {
        clearInterval(timer2);
        observer2.disconnect();
        return;
      }

      if (tryHandleStep2Page('poll')) {
        handled = true;
        clearInterval(timer2);
        observer2.disconnect();
        return;
      }

      if (Date.now() - waitStart > maxWaitMs) {
        clearInterval(timer2);
        observer2.disconnect();
        // 长时间仍未检测到任何特殊页面，回退到结果轮询逻辑
        showStatus('⚠️ 当前页面不支持自动操作，已切换为结果轮询。', 'gray');
        startPollingResult();
      }
    }, 500);
  });
})();
