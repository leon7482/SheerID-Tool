;(function () {
  if (!location.hostname.includes('sheerid')) return;

  function getSheerIdContext() {
    const params = new URLSearchParams(window.location.search);
    let verificationId = params.get('verificationId');

    if (!verificationId) {
      const parts = window.location.pathname.split('/');
      const last = parts[parts.length - 1] || '';
      if (/^[0-9a-fA-F]{24}$/.test(last)) {
        verificationId = last;
      }
    }

    let deviceFingerprintHash = null;
    try {
      deviceFingerprintHash =
        window.sheerId?.deviceFingerprintHash ||
        window.SheerId?.deviceFingerprintHash ||
        null;
    } catch (_) {}

    let apiOrigin = 'https://services.sheerid.com';
    try {
      const si = window.sheerId || window.SheerId;
      const statusUrl =
        si?.verificationDetails?.statusUrl ||
        si?.statusUrl ||
        si?.config?.statusUrl;
      if (statusUrl) {
        apiOrigin = new URL(statusUrl).origin;
      }
    } catch (_) {}

    return { verificationId, deviceFingerprintHash, apiOrigin };
  }

  async function searchSchoolApi(schoolName) {
    if (!schoolName) return null;
    try {
      const res = await fetch(
        `https://orgsearch.sheerid.net/rest/organization/search?name=${encodeURIComponent(
          schoolName,
        )}`,
      );
      const data = await res.json();
      if (!Array.isArray(data) || data.length === 0) return null;

      const filtered = data.filter((x) => {
        const t = String(x.type || '').toUpperCase();
        return !['HIGH SCHOOL', 'K12', 'PRIMARY', 'SECONDARY'].includes(t);
      });

      const target = filtered.length ? filtered[0] : data[0];
      target.idExtended = String(target.idExtended || target.id);
      return target;
    } catch (e) {
      console.warn('[SheerID-bot] searchSchoolApi error:', e);
      return null;
    }
  }

  async function submitPersonalInfo(identity) {
    const ctx = getSheerIdContext();
    if (!ctx.verificationId) {
      return { success: false, error: 'Verification ID not found' };
    }

    const schoolObj = await searchSchoolApi(identity.schoolName);
    if (!schoolObj) {
      return { success: false, error: 'School not found via API' };
    }

    const payload = {
      firstName: identity.firstName,
      lastName: identity.lastName,
      email: identity.email,
      birthDate: identity.birthDate, // YYYY-MM-DD
      organization: {
        id: schoolObj.idExtended,
        name: schoolObj.name,
      },
      country: schoolObj.country || 'US',
      locale: 'en-US',
      deviceFingerprintHash: ctx.deviceFingerprintHash || undefined,
    };

    const url = `${ctx.apiOrigin}/rest/v2/verification/${ctx.verificationId}/step/collectStudentPersonalInfo`;

    let response;
    let text = '';
    try {
      response = await fetch(url, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json, text/plain, */*',
        },
        body: JSON.stringify(payload),
      });
      text = await response.text();
    } catch (e) {
      return { success: false, error: e?.message || String(e) };
    }

    if (!text) {
      if (response.ok) {
        return { success: true, nextStep: null };
      }
      return {
        success: false,
        status: response.status,
        error: 'Empty response from SheerID',
      };
    }

    let json = null;
    try {
      json = JSON.parse(text);
    } catch (_) {
      if (response.ok) {
        return { success: true, nextStep: null, raw: text };
      }
      return {
        success: false,
        status: response.status,
        error: text,
      };
    }

    if (response.ok) {
      return {
        success: true,
        nextStep: json.currentStep || null,
        raw: json,
      };
    }

    const errMsg =
      json.systemErrorMessage ||
      json.errorMessage ||
      json.message ||
      text;

    return {
      success: false,
      status: response.status,
      error: errMsg,
      raw: json,
    };
  }

  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    const data = event.data || {};
    if (data.type !== 'EXECUTE_API_SUBMISSION') return;

    try {
      const result = await submitPersonalInfo(data.identity || {});
      window.postMessage(
        {
          type: 'API_SUBMISSION_RESULT',
          result,
        },
        '*',
      );
    } catch (e) {
      window.postMessage(
        {
          type: 'API_SUBMISSION_RESULT',
          result: { success: false, error: e?.message || String(e) },
        },
        '*',
      );
    }
  });
})();
