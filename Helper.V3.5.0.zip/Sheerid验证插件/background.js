// background.js

const BACKEND_URL = "https://my-sheerid-bot.vercel.app/api/run";

let shouldCloseNextPopup = false;

const ALLOWED_UI_MESSAGES = new Set([
  "🚀 正在执行后端任务…",
  "✅ 后端任务已执行，等待结果…",
]);

function appendTaskLog(text) {
  if (ALLOWED_UI_MESSAGES.has(text)) {
    writeLog(text);
    return;
  }

  if (typeof text === "string" && text.startsWith("❌ 后端任务触发失败:")) {
    writeLog(text);
  }
}

function writeLog(text) {
  const entry = { time: Date.now(), text };
  chrome.storage.local.get({ taskLogs: [] }, (data) => {
    const logs = Array.isArray(data.taskLogs) ? data.taskLogs : [];
    logs.push(entry);
    chrome.storage.local.set({ taskLogs: logs });
  });
}

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.type === "TRIGGER_CLOUD_UPLOAD") {
    const { token, targetUrl, identity } = req.data || {};

    console.log("[Background][Upload] 收到上传请求", { targetUrl });

    appendTaskLog("🚀 正在执行后端任务…");

    handleCloudUpload(token, targetUrl, identity)
      .then((res) => {
        if (res && res.success) {
          appendTaskLog("✅ 后端任务已执行，等待结果…");
        } else {
          const msg = res && res.msg ? res.msg : "未知错误";
          appendTaskLog(`❌ 后端任务执行失败: ${msg}`);
        }

        sendResponse(res);
      })
      .catch((err) => {
        console.error("[Background][Upload] 云端上传异常:", err);
        const msg = err?.message || "未知错误";
        appendTaskLog(`❌ 后端任务执行失败: ${msg}`);
        sendResponse({
          success: false,
          msg,
        });
      });

    return true;
  }

  if (req.type === "CLOSE_NEW_POPUP") {
    console.log("[Background][Popup] 将自动关闭下一次新打开的标签页");
    // 这类内部调试日志只在控制台显示，不写入 popup
    shouldCloseNextPopup = true;
    sendResponse({ ok: true });
    return;
  }
});

// 调用云端后端 /api/run
async function handleCloudUpload(token, targetUrl, identity) {
  try {
    if (!token) {
      console.warn(
        "[Background][Upload] 缺少 Turnstile token，拒绝执行云端上传"
      );
      return {
        success: false,
        msg: "缺少 Turnstile token，无法执行上传",
      };
    }

    const payload = {
      token,
      targetUrl,
      identity,
    };

    const headers = {
      "Content-Type": "application/json",
    };

    const resp = await fetch(BACKEND_URL, {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
    });

    if (!resp.ok) {
      let msg = `HTTP ${resp.status} ${resp.statusText}`;

      try {
        const text = await resp.text();
        console.warn(
          "[Background][Upload] HTTP 非 2xx：",
          resp.status,
          resp.statusText,
          text
        );

        try {
          const json = JSON.parse(text);
          if (json && json.msg) {
            msg = json.msg;
          } else if (text) {
            msg = text;
          }
        } catch {
          if (text) msg = text;
        }
      } catch (e) {
        console.warn(
          "[Background][Upload] 读取错误响应 body 失败:",
          e
        );
      }

      return {
        success: false,
        msg,
      };
    }

    const data = await resp.json().catch(() => ({}));
    console.log("[Background][Upload] 云端上传返回：", data);
    return data;
  } catch (e) {
    console.error("[Background][Upload] 云端上传异常:", e);
    return {
      success: false,
      msg: e?.message || "Network error",
    };
  }
}

// 自动关闭下一个新打开的标签页（SSO 登录弹窗）
chrome.tabs.onCreated.addListener((tab) => {
  if (!shouldCloseNextPopup) return;

  shouldCloseNextPopup = false;

  setTimeout(() => {
    try {
      chrome.tabs.get(tab.id, (existingTab) => {
        if (chrome.runtime.lastError) {
          console.warn(
            "[Background][Popup] 获取新建标签失败：",
            chrome.runtime.lastError.message
          );
          return;
        }
        if (!existingTab) return;

        console.log(
          `[Background][Popup] 检测到新窗口 (ID: ${tab.id})，正在执行自动关闭...`
        );

        chrome.tabs.remove(tab.id, () => {
          if (chrome.runtime.lastError) {
            console.warn(
              "[Background][Popup] 关闭窗口失败（可能已手动关闭）：",
              chrome.runtime.lastError.message
            );
          }
        });
      });
    } catch (e) {
      console.error(
        "[Background][Popup] 自动关闭新窗口时异常：",
        e
      );
    }
  }, 1200);
});
