const FIRST_NAMES = [
  "Liam", "Noah", "Ethan", "Aiden", "Mason", "Lucas", "Logan", "Jacob", "Michael", "Daniel", 
  "Elijah", "James", "Benjamin", "Owen", "Carter", "Caleb", "Wyatt", "Jayden", "Ryan", "Landon",
  "Olivia", "Emma", "Ava", "Sophia", "Isabella", "Mia", "Amelia", "Harper", "Evelyn", "Ella",
  "Madison", "Chloe", "Lily", "Grace", "Zoey", "Riley", "Nora", "Hannah", "Aria"
];

const LAST_NAMES = [
  "Johnson", "Williams", "Brown", "Jones", "Garcia", "Martinez", "Rodriguez", "Hernandez", "Lopez", 
  "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", 
  "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson"
];

const TARGET_SCHOOL_NAME = "Atlanta Technical College"; 

const MAJORS_DATA = [
  { name: "Accounting — Associate of Applied Science (AAS)", college: "Business & Computer Tech" },
  { name: "Business Management — Associate of Applied Science (AAS)", college: "Business & Computer Tech" },
  { name: "Cybersecurity — Associate of Applied Science (AAS)", college: "Business & Computer Tech" },
  { name: "Medical Assisting — Diploma", college: "Health & Public Safety Tech" }
];

function getRandomItem(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function getRandomInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }

window.generateLocalIdentity = function() {
    const fn = getRandomItem(FIRST_NAMES);
    const ln = getRandomItem(LAST_NAMES);
    const majorObj = getRandomItem(MAJORS_DATA);
    
    const year = new Date().getFullYear() - getRandomInt(19, 24);
    const month = String(getRandomInt(1, 12)).padStart(2, '0');
    const day = String(getRandomInt(1, 28)).padStart(2, '0');

    return {
        firstName: fn,
        lastName: ln,
        fullName: `${fn} ${ln}`,
        initials: (fn[0] + ln[0]).toUpperCase(),
        email: `${fn.toLowerCase()}.${ln.toLowerCase()}.${getRandomInt(10,99)}@gmail.com`,
        birthDate: `${year}-${month}-${day}`,
        schoolName: TARGET_SCHOOL_NAME,
        majorName: majorObj.name,
        collegeName: majorObj.college,
        studentId: "900" + getRandomInt(100000, 999999)
    };
};