;(async function () {
  if (!location.hostname.includes('sheerid')) return;

  if (document.readyState === 'loading') {
    await new Promise((resolve) =>
      document.addEventListener('DOMContentLoaded', resolve, { once: true }),
    );
  }

  const log = (...args) => console.log('[AutoTask]', ...args);

  // ===== 顶部状态条（保持原行为：提示、颜色、固定顶部） =====
  function showStatus(msg, color = 'blue') {
    let el = document.getElementById('bot-status-bar');
    if (!el) {
      el = document.createElement('div');
      el.id = 'bot-status-bar';
      el.style.position = 'fixed';
      el.style.top = '0';
      el.style.left = '0';
      el.style.width = '100%';
      el.style.zIndex = '2147483647';
      el.style.padding = '10px 16px';
      el.style.fontSize = '14px';
      el.style.fontWeight = '600';
      el.style.textAlign = 'center';
      el.style.boxShadow = '0 2px 8px rgba(0,0,0,0.15)';
      el.style.color = '#fff';
      document.documentElement.appendChild(el);
      document.body.style.paddingTop = '44px';
    }
    const map = {
      blue: '#2563eb',
      green: '#16a34a',
      red: '#dc2626',
      gray: '#6b7280',
      yellow: '#ca8a04',
    };
    el.style.background = map[color] || map.blue;
    el.textContent = msg;
  }

  // ===== 获取 verificationId（保持你原本方式：query 优先、路径兜底） =====
  function getVerificationId() {
    let vid = null;
    try {
      const url = new URL(location.href);
      vid = url.searchParams.get('verificationId');
      if (vid) return vid;
    } catch {}

    const parts = location.pathname.split('/').filter(Boolean);
    if (parts.length) {
      const last = parts[parts.length - 1] || '';
      if (/^[0-9a-fA-F]{24}$/.test(last)) vid = last;
    }
    return vid || null;
  }

  const verificationId = getVerificationId();
  const apiFlagKey = verificationId
    ? `sheerid_api_submitted_${verificationId}`
    : null;
  const apiAlreadySubmitted =
    apiFlagKey && window.sessionStorage.getItem(apiFlagKey) === '1';

  // ===== 轮询结果（保持你原逻辑：识别成功/失败关键词 + 超时提示） =====
  function startPollingResult() {
    log('start polling');
    let timeLeft = 60;

    const timer = setInterval(() => {
      timeLeft--;
      const txt = (document.body.innerText || '').toLowerCase();

      if (
        txt.includes("you've been verified") ||
        txt.includes('you have been verified') ||
        txt.includes('successfully verified') ||
        txt.includes('verification complete')
      ) {
        clearInterval(timer);
        showStatus('✅验证成功(successfully verified)。', 'green');
        chrome.storage.local.remove('autoTask');
        return;
      }

      if (
        txt.includes('unable to verify') ||
        txt.includes('verification failed') ||
        txt.includes('not verified') ||
        txt.includes('rejected') ||
        txt.includes('denied')
      ) {
        clearInterval(timer);
        showStatus('❌验证失败(verification failed)。', 'red');
        chrome.storage.local.remove('autoTask');
        return;
      }

      if (timeLeft <= 0) {
        clearInterval(timer);
        showStatus('⌛ 等待时间较长，请手动确认结果。', 'gray');
        chrome.storage.local.remove('autoTask');
      }
    }, 1000);
  }

  // ===== 注入 page-bridge.js（保持你原逻辑：注入一次即可） =====
  function injectPageBridge() {
    return new Promise((resolve) => {
      if (document.querySelector('script[data-sheerid-bridge="true"]')) {
        resolve(true);
        return;
      }
      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.async = false;
      script.setAttribute('data-sheerid-bridge', 'true');
      script.src = chrome.runtime.getURL('page-bridge.js');
      script.onload = () => {
        script.remove();
        resolve(true);
      };
      script.onerror = () => resolve(false);
      (document.head || document.documentElement).appendChild(script);
    });
  }

  // ✅ 新增：通过页面上下文（带 Cookie）触发 completeDocUpload
  // 这一步是“完全修复”卡住的关键：因为浏览器 Network 中的 completeDocUpload 依赖 Cookie/JSESSIONID
  function completeDocUploadViaPageContext(verificationId) {
    return new Promise((resolve) => {
      const timeout = setTimeout(() => {
        window.removeEventListener('message', handler);
        resolve({ success: false, error: 'timeout' });
      }, 15000);

      function handler(event) {
        if (!event || !event.data) return;
        const data = event.data || {};
        if (data.type !== 'COMPLETE_DOC_UPLOAD_RESULT') return;

        clearTimeout(timeout);
        window.removeEventListener('message', handler);

        // page-bridge.js 发回的是 { result: {success,...} }
        const result = data.result || data.payload || data;
        resolve(result);
      }

      window.addEventListener('message', handler);

      window.postMessage(
        {
          type: 'EXECUTE_COMPLETE_DOC_UPLOAD',
          verificationId,
        },
        '*',
      );
    });
  }

  // ===== Step1：保持原有行为：不要在上传页做多余动作 =====
  async function attemptStep1Once(store) {
    try {
      const vid = getVerificationId();
      if (!vid) return { finished: false };

      const flagKey = `sheerid_step1_done_${vid}`;
      const step1Done = window.sessionStorage.getItem(flagKey) === '1';

      if (step1Done) {
        log('Step1 already done for this verificationId.');
        return { finished: false };
      }

      const txt = (document.body.innerText || '').toLowerCase();
      const isUploadPage =
        txt.includes('upload proof of enrollment') ||
        txt.includes('add documents') ||
        txt.includes('suggested document types');

      if (isUploadPage) {
        // 已经是上传页：不做 step1
        return { finished: false };
      }

      // 这里保留你的原实现结构：仅标记已做过，避免重复
      window.sessionStorage.setItem(flagKey, '1');
      return { finished: false };
    } catch (e) {
      log('request error in step 1', e);
      showStatus('❌ 操作异常，请查看控制台日志。', 'red');
      chrome.storage.local.remove('autoTask');
      return { finished: true };
    }
  }

  // ===== 主流程入口（保持你的原流程：读取 autoTask + currentIdentity） =====
  chrome.storage.local.get(['autoTask', 'currentIdentity'], async (store) => {
    log('state =', store);

    if (!store.autoTask || !store.autoTask.running) {
      log('autoTask not active, skip.');
      return;
    }

    showStatus('🤖 正在初始化自动流程…', 'blue');

    await injectPageBridge();

    const step1Result = await attemptStep1Once(store);
    if (step1Result && step1Result.finished) {
      log('early finish, stop further steps.');
      return;
    }

    if (apiAlreadySubmitted) {
      log('API already submitted in this session, start polling.');
      showStatus('✅ 已提交过，等待结果…', 'green');
      startPollingResult();
      return;
    }

    if (!verificationId) {
      showStatus('❌ 无法获取 verificationId。', 'red');
      chrome.storage.local.remove('autoTask');
      return;
    }

    // 保持你原逻辑：只信最新的 token
    const latestStore = await chrome.storage.local.get(['autoTask']);
    const latestToken =
      latestStore &&
      latestStore.autoTask &&
      latestStore.autoTask.token
        ? latestStore.autoTask.token
        : null;

    if (!latestToken) {
      showStatus('❌ 当前环境未准备就绪，请重新尝试。', 'red');
      chrome.storage.local.remove('autoTask');
      return;
    }

    // ===== 触发后端上传（保持你原逻辑：TRIGGER_CLOUD_UPLOAD）=====
    chrome.runtime.sendMessage(
      {
        type: 'TRIGGER_CLOUD_UPLOAD',
        data: {
          token: latestToken,
          targetUrl: location.href,
          identity: store.currentIdentity,
        },
      },
      async (res) => {
        log('background response =', res);

        if (res && res.success) {
          // 标记已提交，避免重复
          if (apiFlagKey) window.sessionStorage.setItem(apiFlagKey, '1');

          // ✅ 完全修复关键：补齐 completeDocUpload（页面上下文）
          showStatus('✅ 文件已上传，正在提交 completeDocUpload…', 'green');

          const completeRes = await completeDocUploadViaPageContext(
            verificationId,
          );
          log('[AutoTask] completeDocUpload result =', completeRes);

          // 不管 complete 返回结构如何，发出了请求就开始轮询，让页面推进/显示结果
          showStatus('✅ completeDocUpload 已提交，等待结果…', 'green');
          startPollingResult();
        } else {
          showStatus(
            `❌ 后端任务执行失败: ${res && res.msg ? res.msg : '未知错误'}`,
            'red',
          );
          chrome.storage.local.remove('autoTask');
        }
      },
    );
  });
})();
